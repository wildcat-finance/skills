Fiat checkpoint archive

This archive carries one Fiat run at one accepted boundary: the controller
capsule, a complete-history Git bundle of the run's refs, the signature proof
for the run's receipted commits, the signer's public key material, and the
semantic checkpoint identity. checkpoint.json is the content manifest; every
other member is listed there with its exact size and SHA-256.

Restore rule. Verify before extracting anything:

  hexctl checkpoint inspect --archive checkpoint.zip --sha256 <outer-hex>
  hexctl --dir <empty-destination> checkpoint restore \
      --archive checkpoint.zip --sha256 <outer-hex>

The outer SHA-256 travels beside this archive in checkpoint.zip.sha256 and is
handed over separately. The restored run executes nothing: it waits for the
operator's explicit `hexctl next`.
